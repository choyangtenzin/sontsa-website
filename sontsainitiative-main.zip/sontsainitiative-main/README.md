# sontsa-website
Sontsa Initiative's official website

Link to figma prototype: https://www.figma.com/file/6qakSMcAM8vxGMeCJgRNBn/Sontsa-Website-Mockup?node-id=0%3A1&t=HLhCCfWA6qsBD8Nl-1

Website planning google doc: https://docs.google.com/document/d/1tQl6dmKwZbmotVzewIuEFIIpCeS4Aan0dt6cgmEo_vM/edit?usp=sharing
